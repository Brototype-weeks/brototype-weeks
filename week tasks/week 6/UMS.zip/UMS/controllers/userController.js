// const userModel = require("../models/userModel");
const User = require("../models/userModel");
const bcrypt = require('bcrypt');

// load register 
const loadRegister = async (req, res) => {
  try {
    if (req.session.user) {
      res.redirect('/homePage')
    } else {
      const msg = req.flash("msg");
      res.render('register',{msg})
    }
  } catch (error) {
    console.log(error.message);
  }
};

// insert user
const insertUser = async (req, res) => {
  try {
    const Existuser = await User.findOne({email:req.body.email})
        if (Existuser) {
            req.flash("msg","user alredy exist")
       return res.redirect('/register')
        } 

    console.log(req.body.email);
    
    const saltRounds = 10; // Define the number of salt rounds
    const hashedPassword = await bcrypt.hash(req.body.password, saltRounds);

    const user = new User({
      name: req.body.name,
      email: req.body.email,
      phone: req.body.phone,
      password: hashedPassword,
      isAdmin: 0,
    });

    const userData = await user.save();

    if (userData) {
      req.flash("msg", "Signup sussess!");
      res.redirect("/login");
    } else {
      res.redirect("/register");
    }
  } catch (error) {
    console.log(error.message);
  }
};



// veirfy the user login
const isVerify = async (req, res)=>{
  try {
    if (req.session.user) {
      return res.redirect('/homePage')
    }
    // next()
  } catch (error) {
    console.log(error);
  }
}




//load login page
const loadLogin = async (req, res) => {
  try {
    if (req.session.user) {
      res.redirect('/homePage')
    } else {
      const msg = req.flash("msg");
      const fail = req.flash("fail");
      res.render('login',{msg,fail})
    }

  } catch (error) {
    console.log(error.message);
  }
};


//load homePage

const homePage = async (req, res)=>{
  try {
    const userExist = await User.findOne({email:req.session.email});    
    if(userExist){
    if (req.session.user) {
        username = req.session.user
      res.render('homePage',{username:username})
    }else{
      res.redirect('/login')
    }
  }else{
    delete req.session.user;
    req.flash('fail',"admin banned your account")
    res.redirect('/login')
  }

  } catch (error) {
    console.log(error);
  }
}

// load logout 

const logout = async (req, res )=>{
  try {
    if (req.session.user) {
      req.session.destroy();
    res.redirect('/login')
    }
    
  } catch (error) {
    console.log(error);
  }
}


module.exports = {
  loadRegister,
  insertUser,
  loadLogin,
  homePage,
  logout,
  isVerify

};
