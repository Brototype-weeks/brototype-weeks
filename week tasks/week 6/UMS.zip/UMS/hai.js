console.log(null == undefined);
